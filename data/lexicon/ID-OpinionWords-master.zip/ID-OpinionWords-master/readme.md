List of Opinion Words (positive/negative) in Bahasa Indonesia. Originated by Liu's Opinion Words list with modification/translation to Indonesia.

#REFERENCES
If you use this list, please cite the following papers:
- Wahid, D. H., & Azhari, S. N. (2016). Peringkasan Sentimen Esktraktif di Twitter Menggunakan Hybrid TF-IDF dan Cosine Similarity. IJCCS (Indonesian Journal of Computing and Cybernetics Systems), 10(2), 207-218.
- Liu, Bing, Hu, Minqing, and Cheng, Junsheng (2005). "Opinion Observer: Analyzing and Comparing Opinions on the Web." Proceedings of the 14th International World Wide Web Conference (WWW-2005), May 10-14, Chiba, Japan.

